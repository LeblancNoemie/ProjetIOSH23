//
//  Depense+CoreDataClass.swift
//  Projet IOS H23
//
//  Created by Noemie Leblanc Lessard on 2023-03-08.
//
//

import Foundation
import CoreData


public class Depense: NSManagedObject {

}
