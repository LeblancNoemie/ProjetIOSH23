//
//  IDataManager.swift
//  Projet IOS H23
//
//  Created by Noemie Leblanc Lessard on 2023-03-14.
//

import Foundation
protocol IDataManager{
    func getAll()
}
