//
//  CompteDetails2ViewController.swift
//  Projet IOS H23
//
//  Created by Noemie Leblanc Lessard on 2023-03-10.
//

import UIKit

class CompteDetails2ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
